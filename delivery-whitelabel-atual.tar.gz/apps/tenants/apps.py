from django.apps import AppConfig


class TenantsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.tenants'
    verbose_name = "Gestão de Loja"

    def ready(self):
        from . import signals  # noqa: F401
